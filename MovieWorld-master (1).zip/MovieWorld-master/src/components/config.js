export const img_300 = "https://image.tmdb.org/t/p/w300";
